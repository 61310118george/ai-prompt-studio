import { isDeveloper } from './developer-mode.js';
const response = result => {if(!result?.ok)throw Error(result?.error||'API 操作失敗');return result.data;};
const publishCloudStatus = status => document.dispatchEvent(new CustomEvent('cloud-status-changed',{detail:status}));

export function mountCloudSettings(bridge) {
  const panel=document.createElement('section');panel.className='panel setting-card cloud-settings';
  panel.innerHTML=`<h3>選用：AI 輔助分析</h3><p>Gemini 提供部分模型免費額度，須自行申請 API Key。這是輔助分析服務，不是工作台「預計使用的工具」。</p>
    <div class="prompt-fields"><label>分析服務<input value="Google Gemini API" disabled></label>
    <label>模型 ID<input id="cloudModel" value="gemini-3.5-flash-lite" maxlength="90" spellcheck="false"></label>
    <label id="cloudKeyLabel">API Key（只儲存在此電腦）<input id="cloudKey" type="password" autocomplete="off" spellcheck="false" placeholder="貼上完整 Google AI Studio Key"></label>
    <p class="field-help" id="cloudKeyHelp">Key 只存在目前作業系統使用者的 App 本機資料，不會寫入 SQLite、專案檔或應用程式安裝目錄。換到其他電腦或帳號時，不會帶出 Key。</p>
    <div class="inline-actions"><button class="button primary" id="cloudSave">測試並啟用</button><button class="button secondary" id="cloudClear">清除金鑰／停用</button></div>
    <p id="cloudStatus" role="status">未啟用，維持離線模式。</p></div>
    <p class="source-note">免費不代表無限使用。Gemini 免費服務可能將輸入與回覆用於產品改進；請勿傳送個資、密碼或機密。啟用計費的帳號可能產生費用，App 無法判斷你的方案，也不會替你開通付費。</p>
    <p><a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">取得 Gemini Key</a> · <a href="https://ai.google.dev/gemini-api/docs/pricing" target="_blank" rel="noreferrer">免費模型與價格</a> · <a href="https://ai.google.dev/gemini-api/docs/rate-limits" target="_blank" rel="noreferrer">用量限制</a></p>
    <p class="field-help">替代方案：Groq 也有受限免費方案，本版尚未接入。查證：2026-10-07。</p>`;
  document.querySelector('.settings-layout').prepend(panel);
  const $=id=>panel.querySelector(`#${id}`);
  const status=s=>{
    const labels={connected:`已連結 Gemini（${s.model}）。${s.connection_message||''}`,error:`API 連線異常：${s.connection_message||'請確認 Key、模型與網路。'}`,checking:'正在送出測試請求…',unverified:'已讀取儲存的 Key，請按「測試並啟用」確認。',unconfigured:'未啟用，維持離線模式。'};
    $('cloudStatus').textContent=labels[s.connection]||labels.unconfigured;
    const saved=Boolean(s.key_saved);
    $('cloudKeyLabel').firstChild.textContent=saved?'API Key（本機已儲存）':'API Key（只儲存在此電腦）';
    $('cloudKey').placeholder=saved?'本機已有 Key；留空可重新測試，貼上新 Key 可取代':'貼上完整 Google AI Studio Key';
    $('cloudKeyHelp').textContent=saved?'Key 僅存在目前作業系統使用者的 App 本機資料，不會包進安裝檔或提供給其他使用者。留空後按「測試並啟用」會重新測試；貼上新 Key 可取代目前 Key。':'Key 只存在目前作業系統使用者的 App 本機資料，不會寫入 SQLite、專案檔或應用程式安裝目錄。換到其他電腦或帳號時，對方必須自行貼上自己的 Key。';
    publishCloudStatus(s);
  };
  async function configure(clear){
    $('cloudSave').disabled=true;$('cloudClear').disabled=true;
    if(!clear)status({connection:'checking',connection_message:'正在送出最小測試請求。'});
    try {status(response(await bridge.call('configure_cloud_analysis',clear?{clear:true}:{api_key:$('cloudKey').value.trim(),model:$('cloudModel').value.trim()})));document.dispatchEvent(new Event('cloud-settings-changed'));}
    catch(e){$('cloudStatus').textContent=e.message;bridge.call('get_cloud_settings').then(response).then(publishCloudStatus).catch(()=>publishCloudStatus({connection:'error',connection_message:e.message}));}
    finally{$('cloudKey').value='';$('cloudSave').disabled=false;$('cloudClear').disabled=false;}
  }
  $('cloudSave').onclick=()=>configure(false);$('cloudClear').onclick=()=>configure(true);
  bridge.call('get_cloud_settings').then(response).then(status).catch(e=>{$('cloudStatus').textContent=e.message;publishCloudStatus({connection:'error',connection_message:e.message});});
}

export function mountCloudAnalysis({root,bridge,content,onApply}){
  const box=document.createElement('details');box.className='cloud-analysis';
  box.innerHTML=`<summary>選用：請 AI 分析任務</summary><p class="field-help">使用設定中的 Gemini 分析目前草稿。只送出草稿與工具名稱，不讀取或上傳專案檔案、路徑與帳號用量。</p>
    <div class="inline-actions cloud-analysis-actions"><button class="button secondary" id="cloudAnalyze">檢查並送出分析</button><button class="button primary hidden" id="cloudOptimize">AI 優化</button></div>
    <p id="cloudAnalysisStatus" role="status"></p><pre id="cloudResult" class="code-view hidden"></pre>
    <section id="cloudOptimization" class="ai-optimization hidden" aria-live="polite">
      <div class="ai-comparison"><section><h4>優化前</h4><pre class="code-view" id="cloudOriginal"></pre></section><section><h4>優化後</h4><pre class="code-view" id="cloudOptimized"></pre></section></div>
      <details open><summary>逐行變更差異</summary><div class="diff-view" id="cloudOptimizationDiff" role="region" aria-label="AI 優化差異"></div></details>
      <div class="inline-actions"><button class="button primary" id="cloudApplyOptimization">套用優化結果</button><span class="field-help" id="cloudOptimizationNote"></span></div>
    </section>`;
  root.append(box);
  const analyzeButton=box.querySelector('#cloudAnalyze'),optimizeButton=box.querySelector('#cloudOptimize'),applyButton=box.querySelector('#cloudApplyOptimization');
  const status=box.querySelector('#cloudAnalysisStatus'),result=box.querySelector('#cloudResult'),optimizationPanel=box.querySelector('#cloudOptimization');
  let epoch=0,busy=false,lastAnalysis=null,optimization=null;
  const renderDiff=text=>{
    const target=box.querySelector('#cloudOptimizationDiff');target.replaceChildren();
    if(!text?.trim()){const message=document.createElement('div');message.className='diff-message';message.textContent='AI 判斷目前內容不需要調整。';target.append(message);return;}
    let oldLine=0,newLine=0;
    for(const line of text.split('\n')){
      const row=document.createElement('div');row.className='diff-row';
      let kind='context',oldNumber='',newNumber='';
      if(line.startsWith('---')||line.startsWith('+++'))kind='meta';
      else if(line.startsWith('@@'))kind='hunk';
      else if(line.startsWith('-')){kind='remove';oldLine++;oldNumber=oldLine;}
      else if(line.startsWith('+')){kind='add';newLine++;newNumber=newLine;}
      else {oldLine++;newLine++;oldNumber=oldLine;newNumber=newLine;}
      row.classList.add(`diff-${kind}`);
      for(const [className,value] of [['diff-old-number',oldNumber],['diff-new-number',newNumber],['diff-code',line]]){const span=document.createElement('span');span.className=className;span.textContent=String(value);row.append(span);}
      target.append(row);
    }
  };
  function invalidate(){
    epoch++;lastAnalysis=null;optimization=null;result.textContent='';result.classList.add('hidden');
    optimizeButton.classList.add('hidden');optimizationPanel.classList.add('hidden');
    for(const id of ['cloudOriginal','cloudOptimized','cloudOptimizationDiff'])box.querySelector(`#${id}`).replaceChildren();
    status.textContent=busy?'草稿已變更，舊結果不會套用。':'';
  }
  root.querySelector('#usageTool').addEventListener('change',invalidate);document.addEventListener('cloud-settings-changed',invalidate);
  document.addEventListener('developer-mode-changed',invalidate);
  analyzeButton.onclick=async()=>{
    if(busy||!isDeveloper())return;
    const text=content(),tool=root.querySelector('#usageTool').value;
    const estimatedTokens=Number(root.querySelector('#usageEstimate')?.dataset.tokens||0);
    const modelHint=root.querySelector('#usageModel')?.dataset.model||'';
    if(tool==='local'){status.textContent='本機模型維持離線提示；若要使用雲端分析，請選擇雲端工具。';return;}
    if(!text.trim()||text.length>20000){status.textContent='請提供 1 至 20,000 字元的草稿。';return;}
    busy=true;analyzeButton.disabled=true;optimizeButton.disabled=true;const generation=++epoch;lastAnalysis=null;optimization=null;result.textContent='';result.classList.add('hidden');optimizeButton.classList.add('hidden');optimizationPanel.classList.add('hidden');
    try{
      const settings=response(await bridge.call('get_cloud_settings'));
      if(!settings.configured)throw Error('請先到「設定 → AI 輔助分析」填寫 Gemini API Key。');
      if(generation!==epoch)return;
      if(!window.confirm(`將目前草稿（${text.length} 字元）與工具名稱送往 Google Gemini（${settings.model}）？\n\n不會上傳專案檔案。免費服務可能用於產品改進；若帳號啟用計費，可能產生費用。請先移除機密與個資。`)){status.textContent='已取消，未送出。';return;}
      status.textContent='AI 分析中，最長約 35 秒…';
      const data=response(await bridge.call('analyze_with_ai',{content:text,tool,consent:true,estimated_tokens:estimatedTokens,model_hint:modelHint}));
      bridge.call('get_cloud_settings').then(response).then(publishCloudStatus).catch(()=>{});
      if(generation!==epoch||text!==content())return;
      result.textContent=data.text;result.classList.remove('hidden');lastAnalysis={source:text,text:data.text};optimizeButton.classList.remove('hidden');status.textContent=`${data.provider} · ${data.model}。${data.note}${data.truncated?' 回應已達長度限制，可能不完整。':''}`;
    }catch(e){if(generation===epoch)status.textContent=e.message;bridge.call('get_cloud_settings').then(response).then(publishCloudStatus).catch(()=>{});}
    finally{busy=false;analyzeButton.disabled=false;optimizeButton.disabled=false;}
  };
  optimizeButton.onclick=async()=>{
    if(busy||!lastAnalysis||!isDeveloper())return;
    const text=content(),tool=root.querySelector('#usageTool').value;
    if(text!==lastAnalysis.source){invalidate();status.textContent='草稿已變更，請重新執行 AI 分析。';return;}
    busy=true;analyzeButton.disabled=true;optimizeButton.disabled=true;optimizeButton.textContent='優化中…';const generation=epoch;
    try{
      status.textContent='AI 正在優化提示詞，最長約 45 秒…';
      const data=response(await bridge.call('optimize_with_ai',{content:text,analysis:lastAnalysis.text,tool,consent:true}));
      bridge.call('get_cloud_settings').then(response).then(publishCloudStatus).catch(()=>{});
      if(generation!==epoch||text!==content())return;
      optimization=data;box.querySelector('#cloudOriginal').textContent=data.original;box.querySelector('#cloudOptimized').textContent=data.optimized;renderDiff(data.diff);
      box.querySelector('#cloudOptimizationNote').textContent=`${data.provider} · ${data.model}。${data.note}`;
      applyButton.disabled=!data.changed;optimizationPanel.classList.remove('hidden');status.textContent=data.changed?'AI 優化完成，請先確認差異再套用。':'AI 判斷目前提示詞不需要調整。';
      optimizationPanel.scrollIntoView({behavior:'smooth',block:'nearest'});
    }catch(e){if(generation===epoch)status.textContent=e.message;bridge.call('get_cloud_settings').then(response).then(publishCloudStatus).catch(()=>{});}
    finally{busy=false;analyzeButton.disabled=false;optimizeButton.disabled=false;optimizeButton.textContent='AI 優化';}
  };
  applyButton.onclick=()=>{
    if(!isDeveloper()||!optimization||optimization.original!==content())return;
    onApply(optimization.optimized);status.textContent='已將 AI 優化結果帶回草稿；尚未儲存版本。';
  };
  return invalidate;
}
